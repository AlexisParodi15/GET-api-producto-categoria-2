﻿Imports Microsoft.AspNetCore.Mvc
Imports APIREST.Services

Namespace Controllers
    <Route("api/[controller]")>
    <ApiController>
    Public Class ProductoController
        Inherits ControllerBase

        Private ReadOnly _productoService As IProductoService

        Public Sub New(productoService As IProductoService)
            _productoService = productoService
        End Sub

        ' GET /api/producto/categoria/{categoriaId}
        <HttpGet("categoria/{categoriaId:int}")>
        Public Function ObtenerPorCategoria(categoriaId As Integer) As IActionResult
            Dim productos = _productoService.ObtenerPorCategoriaId(categoriaId)

            ' Si la categoría no existe en la base de datos -> 404 Not Found (Requerimiento 5)
            If productos Is Nothing Then
                Return NotFound(New With {.mensaje = "La categoría solicitada no existe."})
            End If

            ' Si existe (con productos o vacía []) -> 200 OK (Requerimientos 1, 2, 3, 4)
            Return Ok(productos)
        End Function
    End Class
End Namespace
