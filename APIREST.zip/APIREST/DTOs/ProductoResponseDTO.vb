﻿Namespace DTOs
    Public Class ProductoResponseDTO
        Public Property Nombre As String
        Public Property Precio As Decimal
        Public Property CategoriaId As Integer
        Public Property CategoriaNombre As String
    End Class
End Namespace
