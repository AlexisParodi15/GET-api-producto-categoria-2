﻿Imports APIREST.DTOs
Imports APIREST.Repositories

Public Class ProductoService
    Implements IProductoService

    Private ReadOnly _productoRepository As IProductoRepository
    Private ReadOnly _categoriaRepository As ICategoriaRepository

    Public Sub New(productoRepository As IProductoRepository, categoriaRepository As ICategoriaRepository)
        _productoRepository = productoRepository
        _categoriaRepository = categoriaRepository
    End Sub

    Public Function ObtenerPorCategoriaId(categoriaId As Integer) As List(Of ProductoResponseDTO) Implements IProductoService.ObtenerPorCategoriaId
        ' 1. Validar si la categoría existe en la base de datos (Requerimiento 5)
        Dim categoria = _categoriaRepository.ObtenerPorId(categoriaId)
        If categoria Is Nothing Then
            Return Nothing
        End If

        ' 2. Consultar productos de esa categoría
        Dim productos = _productoRepository.ObtenerPorCategoriaId(categoriaId)

        ' 3. Mapear al DTO (devuelve [] automáticamente si no tiene productos) (Requerimiento 4)
        Return productos.Select(Function(p) New ProductoResponseDTO With {
            .Nombre = p.Nombre,
            .Precio = p.Precio,
            .CategoriaId = p.CategoriaId,
            .CategoriaNombre = If(p.Categoria IsNot Nothing, p.Categoria.Descripcion, "")
        }).ToList()
    End Function
End Class
