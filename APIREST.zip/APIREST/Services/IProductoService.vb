﻿Imports APIREST.DTOs

Public Interface IProductoService
    Function ObtenerPorCategoriaId(categoriaId As Integer) As List(Of ProductoResponseDTO)
End Interface
