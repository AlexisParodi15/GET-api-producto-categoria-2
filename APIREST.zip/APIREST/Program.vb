﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Hosting
Imports APIREST.Data
Imports APIREST.Repositories
Imports APIREST.Services

Module Program
    Sub Main(args As String())
        Dim builder = WebApplication.CreateBuilder(args)

        ' Controladores
        builder.Services.AddControllers()

        ' Configuración de Entity Framework Core con SQL Server
        Dim connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
        builder.Services.AddDbContext(Of AppDbContext)(Sub(options)
                                                           options.UseSqlServer(connectionString)
                                                       End Sub)

        ' Inyección de Dependencias de Repositorios y Servicios
        builder.Services.AddScoped(Of ICategoriaRepository, CategoriaRepository)()
        builder.Services.AddScoped(Of IProductoRepository, ProductoRepository)()
        builder.Services.AddScoped(Of IProductoService, ProductoService)()

        ' Configuración de Swagger
        builder.Services.AddEndpointsApiExplorer()
        builder.Services.AddSwaggerGen()

        Dim app = builder.Build()

        ' Habilitar Swagger en entorno de desarrollo
        If app.Environment.IsDevelopment() Then
            app.UseSwagger()
            app.UseSwaggerUI()
        End If

        app.UseAuthorization()
        app.MapControllers()

        app.Run()
    End Sub
End Module
