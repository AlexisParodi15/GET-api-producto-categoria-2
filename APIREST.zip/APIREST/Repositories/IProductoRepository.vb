﻿Imports APIREST.Models

Public Interface IProductoRepository
    Function ObtenerPorCategoriaId(categoriaId As Integer) As List(Of Producto)
End Interface
