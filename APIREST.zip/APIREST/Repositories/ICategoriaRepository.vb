﻿Imports APIREST.Models

Public Interface ICategoriaRepository
    Function ObtenerPorId(id As Integer) As Categoria
End Interface
