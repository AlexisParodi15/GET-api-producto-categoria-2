﻿Imports APIREST.Data
Imports APIREST.Models

Public Class CategoriaRepository
    Implements ICategoriaRepository

    Private ReadOnly _context As AppDbContext

    Public Sub New(context As AppDbContext)
        _context = context
    End Sub

    Public Function ObtenerPorId(id As Integer) As Categoria Implements ICategoriaRepository.ObtenerPorId
        Return _context.Categorias.Find(id)
    End Function
End Class
