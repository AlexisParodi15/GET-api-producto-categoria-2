﻿Imports APIREST.Data
Imports APIREST.Models
Imports Microsoft.EntityFrameworkCore

Public Class ProductoRepository
    Implements IProductoRepository

    Private ReadOnly _context As AppDbContext

    Public Sub New(context As AppDbContext)
        _context = context
    End Sub

    Public Function ObtenerPorCategoriaId(categoriaId As Integer) As List(Of Producto) Implements IProductoRepository.ObtenerPorCategoriaId
        Return _context.Productos _
            .Include(Function(p) p.Categoria) _
            .Where(Function(p) p.CategoriaId = categoriaId) _
            .ToList()
    End Function
End Class