﻿Imports APIREST.Models
Imports Microsoft.EntityFrameworkCore

Namespace Data
    Public Class AppDbContext
        Inherits DbContext

        Public Sub New(options As DbContextOptions(Of AppDbContext))
            MyBase.New(options)
        End Sub

        Public Property Productos As DbSet(Of Producto)
        Public Property Categorias As DbSet(Of Categoria)
    End Class
End Namespace
