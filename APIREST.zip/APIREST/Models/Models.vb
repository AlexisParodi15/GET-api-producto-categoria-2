﻿Imports System.ComponentModel.DataAnnotations.Schema

Namespace Models
    <Table("Categoria")>
    Public Class Categoria
        Public Property Id As Integer
        Public Property Descripcion As String
    End Class
End Namespace