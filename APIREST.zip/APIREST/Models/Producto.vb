﻿Imports System.ComponentModel.DataAnnotations.Schema

Namespace Models
    <Table("Producto")>
    Public Class Producto
        Public Property Id As Integer
        Public Property Nombre As String
        Public Property Precio As Decimal
        Public Property CategoriaId As Integer

        Public Property Categoria As Categoria
    End Class
End Namespace